#include "../include/headerA3.h"

int main() {
    struct car *headLL = NULL;
    int choice;
    char fileName[MAX_LENGTH] = "inputFile.txt"; 

    do {
        printf("\nChoose a menu option:\n");
        printf("1. Add data on a new car\n");
        printf("2. Load data on cars from a given text file\n");
        printf("3. Print data of all cars\n");
        printf("4. Print data of the nth car\n");
        printf("5. Search car data based on carId\n");
        printf("6. Search car data based on model and type\n");
        printf("7. Count the total number of cars in the list\n");
        printf("8. Sort the cars in the list based on carId\n");
        printf("9. Remove data of the nth car\n");
        printf("10. Remove all car data\n");
        printf("11. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addNewCar(&headLL);
                break;

            case 2:

                loadCarData(&headLL, fileName);
                break;

            case 3:
                printAll(headLL);
                break;

            case 4:
                {
                int position;
                printf("Enter the position of the car to print: ");
                scanf("%d", &position);
                printOne(headLL, position);
                }
                break;

            case 5: 
                {
                int searchId;
                printf("Enter carId to search: ");
                scanf("%d", &searchId);

                // Call lookForCarId function to search for the car
                int foundPosition = lookForCarId(headLL, searchId);

                // Check if the car is found and print its details if found
                if (foundPosition != -1) {
                    printf("Car found at position %d!\n", foundPosition);
                    // Optionally, print the details of the car here
                } else {
                    printf("Car with carId %d not found.\n", searchId);
                }
                break;

                    break;
    }
            case 6:
            {
                char modelType[100];
                printf("Enter the model and type (separated by a space): ");

                while(getchar() != '\n'); // removes the newline character at the end

                //scanf("%s", modelType);
                fgets(modelType, 100, stdin);

                modelType[strcspn(modelType, "\n")] = '\0';

                lookForCarModelType(headLL, modelType);
                
                break;
        }
            case 7:
                printf("Total number of cars: %d\n", countCars(headLL));
                break;

            case 8:
                sortCarId(&headLL);
                printf("Cars sorted by carId.\n");
                break;
            case 9:
                {
                int nthCar;
                printf("Currently there are %d cars.\n", countCars(headLL));
                printf("Which car do you wish to remove - enter a value between 1 and %d: ", countCars(headLL));
                scanf("%d", &nthCar);
                oneLessCar(&headLL, nthCar);
                printf("There are now %d car(s) remaining.\n", countCars(headLL));
                break;
                } 

            case 10:
                noMoreCars(&headLL);
                printf("All removed. Linked list is now empty.\n");
                break;

            case 11:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice! Please enter a number between 1 and 11.\n");
                break;
        }

    } while (choice != 11);

    // Free memory before exiting
    struct car *temp;
    while (headLL != NULL) {
        temp = headLL;
        headLL = headLL->nextCar;
        free(temp);
    }

    return 0;   
}