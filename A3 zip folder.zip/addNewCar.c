#include "../include/headerA3.h"
// Function to add a new car to the end of the linked list 
void addNewCar(a3Car **headLL) {

    a3Car *temp = *headLL;
    a3Car *newCar = malloc(sizeof(a3Car));
    int count = 0; 

    // asking the user for car details
    printf("Enter the car model: ");
    scanf("%s", newCar->model);
    printf("Enter the car type: ");
    scanf("%s", newCar->type);
    printf("Enter its year of manufacture: ");
    scanf("%d", &(newCar->year));
    printf("Enter its price: CDN $");
    scanf("%lf", &(newCar->price));

    // using a for loop to calculate carId based on ASCII values of model and length of type

    for (int i = 0; i<strlen(newCar->model);i++){ 
        count = count + newCar->model[i];

    }

    newCar->carId=count+strlen(newCar->type);

    // Checking for uniqueness of carId
    
    while (temp != NULL) {
        if (temp->carId == newCar->carId) { // checks if the first car ID matches the next car ID
            newCar->carId += rand() % 1000; // Add random number
            temp = *headLL; // Reset temp to check from start
        } else {
            temp = temp->nextCar; // moves to the next car/node
        }
    }

    // Insert new car at the end of the linked list
    newCar->nextCar = NULL;
    if (*headLL == NULL) { // checks if LL is empty
        *headLL = newCar;
    } else {
        temp = *headLL; // sets the pointer to the start of the LL
        while (temp->nextCar != NULL) {
            temp = temp->nextCar; // moves to the next car/node
        }
        temp->nextCar = newCar;
    }
    
}