#include "../include/headerA3.h"
// Function to search for a car by its carId in the linked list
int lookForCarId(struct car *headLL, int key) {
    struct car *temp = headLL; // Initialize a temporary pointer to traverse the linked list
    int position = 1; // Initialize the position counter
    
    while (temp != NULL) { // Traverse the linked list
        if (temp->carId == key) {
            return position; // Car found, return its position
        }
        temp = temp->nextCar; // Move to the next car in the linked list
        position++; // Increment the position counter
    }

    return -1; // Car not found, return -1
}