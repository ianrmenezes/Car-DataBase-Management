#include "../include/headerA3.h"
// Function to print details of all cars in the linked list
void printAll(struct car *headLL) {
    if (headLL == NULL) {  // Check if the linked list is empty
        printf("No cars found.\n");
        return;
    }

    int carCount = 0;  // counter for the number of cars
    struct car *currentCar = headLL;  // Initialize a pointer to traverse the linked list

    while (currentCar != NULL) {
        carCount++;  // Increment car count for each car
        printf("Car #%d:\n", carCount);
        printf("Car id: %d\n", currentCar->carId);
        printf("Model: %s\n", currentCar->model);
        printf("Type: %s\n", currentCar->type);
        printf("Price: CDN $%.2lf\n", currentCar->price);
        printf("Year of Manufacture: %d\n", currentCar->year);
        printf("\n");
        currentCar = currentCar->nextCar;  // Move to the next car in the linked list
    }

    printf("Currently, there are %d cars.\n", carCount);  // Prints total number of cars
}

