#include "../include/headerA3.h"
// Function to remove a car from the linked list based on its position
void oneLessCar(struct car **headLL, int whichOne) {
    // Check if the linked list is empty
    if (*headLL == NULL) {
        printf("No cars found.\n");
        return;
    }

    struct car *currentCar = *headLL; // Pointer to traverse the linked list
    struct car *prevCar = NULL; // Pointer to track the previous car
    int currentPosition = 1; // Variable to keep track of the current position

    // Traverse the linked list until the specified position or the end is reached
    while (currentCar != NULL && currentPosition < whichOne) {
        prevCar = currentCar; // Update the previous car pointer
        currentCar = currentCar->nextCar; // Move to the next car
        currentPosition++; // Increment the position counter
    }

    // Check if the specified position is invalid
    if (currentCar == NULL) {
        printf("Invalid car position. Please enter a number between 1 and the total number of cars.\n");
        return;
    }

    // Remove the car from the linked list
    if (prevCar == NULL) {
        *headLL = currentCar->nextCar; // Update the head pointer if the first car is being removed
    } else {
        prevCar->nextCar = currentCar->nextCar; // Update the next pointer of the previous car
    }

    printf("Car [Id: %d] removed.\n", currentCar->carId);
    free(currentCar);
}