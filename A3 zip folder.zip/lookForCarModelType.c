#include "../include/headerA3.h"
// Function to search for a car in the linked list based on model and type
int lookForCarModelType(struct car *headLL, char key[100]) {
    if (headLL == NULL || key == NULL) {   // Check if the linked list or key is empty
        return -1; // Returns -1 if the car is not found or if the input is invalid
    }
    int position = 1;  // Initialize position counter
    // Extract model and type from the search key using strtok
    char *model = strtok(key, " ");
    char *type = strtok(NULL, " ");
    
    struct car *currentCar = headLL; //Initialize pointer to traverse the linked list
   // while loop to Check if the current car's model and type match the search criteria
    while (currentCar != NULL) {
        if (strcmp(currentCar->model, model) == 0 && strcmp(currentCar->type, type) == 0) {
            return position; // Return position if car is found
        }
        position++;
        currentCar = currentCar->nextCar;  // Move to the next car in the linked list
    
    }

    return -1; // Not found
}