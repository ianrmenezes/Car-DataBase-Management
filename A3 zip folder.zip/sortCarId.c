#include "../include/headerA3.h"
// Function to Sort the cars in the list based on carId
void sortCarId(struct car **headLL) {
    if (*headLL == NULL || (*headLL)->nextCar == NULL) {
        return; // checks if theres only one node or empty list
    }

    struct car *last = NULL; // Pointer to the last sorted element
    //check if any swapping has occurred
    int swapped;             

    do {
        swapped = 0;
        struct car *current = *headLL;  // Pointer to traverse the list
        struct car *prev = NULL;       // Pointer to the previous element
        // Traverse until the last sorted element has reached
        while (current->nextCar != last) {
            struct car *nextCar = current->nextCar;

            if (current->carId > nextCar->carId) {  // If current ID is greater than next Id
                if (prev == NULL) {                // If current element is the head of the list
                    *headLL = nextCar;            // Update head to point to next element
                } else {                         // Adjust pointers to skip current element
                    prev->nextCar = nextCar;
                }
                current->nextCar = nextCar->nextCar;  // Swap positions of current and next element
                nextCar->nextCar = current;
                swapped = 1;
            }

            prev = current;   // Move pointers to next elements
            current = nextCar;
        }

        last = current;   // Update last to point to the last sorted element
    } while (swapped);   // Continue sorting until no more swaps are needed

}