#include "../include/headerA3.h"
// Function to Load data on cars from a given text file
void loadCarData(a3Car **headLL, char fileName[MAX_LENGTH]) {
    FILE *file = fopen(fileName, "r");
    if (file == NULL) {  // Check if the file was successfully opened
        printf("Unable to open the file.\n");
        return;
    }

    // Initialize an array to hold each line of the file
    char line[MAX_LENGTH * 5];  // Assuming each line contains up to 5 elements

    //while loop to read each line of the file
    while (fgets(line, sizeof(line), file)) {
        a3Car *newCar = malloc(sizeof(a3Car));  // Allocate memory for a new car structure

        if (newCar == NULL) {
            printf("Memory allocation failed.\n");
            fclose(file);
            return;
        }

        // Use strtok to separate the line into individual values
        char *token = strtok(line, ",");
        if (token == NULL) {
            free(newCar);
            continue;  // Skips this iteration if car ID is missing
        }
        newCar->carId = atoi(token);  // Converts token to integer and assigns to car ID

        // Check for uniqueness of carId
        a3Car *temp = *headLL;
        while (temp != NULL) {
            if (temp->carId == newCar->carId) {
                newCar->carId += rand() % 1000; // Add random number
                temp = *headLL; // Reset temp to check from start
            } else {
                temp = temp->nextCar;
            }
        }

        token = strtok(NULL, ",");
        if (token == NULL) {
            free(newCar);
            continue;  // Skips this iteration if model is missing
        }
        strcpy(newCar->model, token);  // Copy type name to car structure

        token = strtok(NULL, ",");
        if (token == NULL) {
            free(newCar);
            continue;  // Skips this iteration if year is missing.
        }
        strcpy(newCar->type, token);  

        token = strtok(NULL, ",");
        if (token == NULL) {
            free(newCar);
            continue;  // Skips this iteration if year is missing.
        }
        newCar->year = atoi(token);   // Converts token to integer and assigns to year

        token = strtok(NULL, ",");
        if (token == NULL) {
            free(newCar);
            continue;  // Skips this iteration if price is missing
        }
        newCar->price = atof(token);  // Converts token to float and assigns to price

    
        newCar->nextCar = NULL;  // Set the next car pointer to NULL

        // Insert the new car into the linked list
        if (*headLL == NULL) {
            *headLL = newCar;  // If the list is empty, set new car as the head
        } else {
            a3Car *temp = *headLL;
            while (temp->nextCar != NULL) {   // Traverse to the end of the Linked list
                temp = temp->nextCar;
            }
            temp->nextCar = newCar;  // Adds new car at the end
        }
    }

    // Close the file
    fclose(file);  
}
