#include "../include/headerA3.h"
//Function to count the number of cars
int countCars(struct car *headLL) {
    // Initialize count variable to track the number of cars
    int count = 0;
    // Start from the head of the linked list
    struct car *currentCar = headLL;
    // Traverse the linked list and increment count for each car

    while (currentCar != NULL) {
        count++;  // Increment count
        currentCar = currentCar->nextCar; //move to the next car
    }
    return count;  // Returnsthe total count of cars
}