#include <stdio.h>

void sum(int a , int b, int result);

int main (void)
{
    int x, y, z;
    x=5; y = 3;
    sum(x, y, z);
    printf("Sum of %d and %d = %d\n", x, y, z);

    return (0);

}



void sum(int a, int b, int result)
{
    result = a + b;
}