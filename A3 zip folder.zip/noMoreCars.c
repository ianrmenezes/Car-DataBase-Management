#include "../include/headerA3.h"
// Function to Remove all car data
void noMoreCars(struct car **headLL) {
    // Check if the linked list is empty
    if (*headLL == NULL) {
        printf("No cars found.\n");

    }

    // variable to take user input 
    char choice;
    printf("Are you sure you want to remove all car data (enter Yy for yes, Nn for no): ");
    scanf(" %c", &choice);

    // while loop to Check if the choice is valid
    while ((choice != 'Y' && choice != 'y') && (choice != 'N' && choice != 'n')) {
        printf("Invalid choice! Please enter y for yes or n for no: ");
        scanf(" %c", &choice);
    }

    // If yes, remove all cars and reset the head 
    if (choice == 'Y' || choice == 'y') {
        while (*headLL != NULL) {
            struct car *temp = *headLL;
            *headLL = (*headLL)->nextCar;
            free(temp);
        }
        
    }
}