#include "../include/headerA3.h"
// Function to print details of a specific car in the linked list based on its position
void printOne(struct car *headLL, int whichOne) {
    if (headLL == NULL) {  // Check if the linked list is empty
        printf("No cars found.\n");
        return;
    }

    int carCount = countCars(headLL);   // variable that stores the Count of the number of cars in the linked list
    if (whichOne < 1 || whichOne > carCount) {   // Check if the input position is valid
        printf("Invalid car position. Please enter a number between 1 and %d.\n", carCount);
        return;
    }

    struct car *currentCar = headLL;  // Initialize a pointer to traverse the linked list   
    int currentPosition = 1;

    // while loop to Check if the current position matches the required position
    while (currentCar != NULL) {
        if (currentPosition == whichOne) {
            printf("Car id: %d\n", currentCar->carId);
            printf("Model: %s\n", currentCar->model);
            printf("Type: %s\n", currentCar->type);
            printf("Price: CDN $%.2lf\n", currentCar->price);
            printf("Year of Manufacture: %d\n", currentCar->year);
            printf("\n");
            
        }
        currentPosition++;  // Move to the next position
        currentCar = currentCar->nextCar;  // Move to the next car in the linked list
    }
}